package com.andrea._15_Final;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.Map.Entry;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

public class Range {
	String idioma;
	int cantidad;
	
	
	public Range(String idioma, int cantidad) {
		super();
		this.idioma = idioma;
		this.cantidad = cantidad;
	}
	public String getIdioma() {
		return idioma;
	}
	public void setIdioma(String idioma) {
		this.idioma = idioma;
	}
	public int getCantidad() {
		return cantidad;
	}
	public void setCantidad(int cantidad) {
		this.cantidad = cantidad;
	}
	@Override
	public String toString() {
		return "Range [idioma=" + idioma + ", cantidad=" + cantidad + "]";
	}

}
