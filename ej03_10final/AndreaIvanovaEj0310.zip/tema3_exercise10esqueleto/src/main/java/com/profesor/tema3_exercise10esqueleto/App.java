package com.profesor.tema3_exercise10esqueleto;

/**
 * Hello world!
 *
 */
public class App 
{
//    public static void main( String[] args )
//    {
//        System.out.println( "hola, hola" );
//    }
}
