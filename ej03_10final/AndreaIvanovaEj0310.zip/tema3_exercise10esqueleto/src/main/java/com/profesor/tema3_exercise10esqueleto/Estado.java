package com.profesor.tema3_exercise10esqueleto;

public enum Estado {
	ACTIVO, PENDIENTE, INACTIVO
}
