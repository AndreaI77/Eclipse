package com.profesor.tema3_exercise10esqueleto;

public enum Grupo {
	A1,A2,C1,C2,AP
}
