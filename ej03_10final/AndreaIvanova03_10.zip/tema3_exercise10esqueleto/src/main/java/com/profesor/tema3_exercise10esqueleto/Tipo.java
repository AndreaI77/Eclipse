package com.profesor.tema3_exercise10esqueleto;

public enum Tipo {
	NORMAL, PREMIUM
}
